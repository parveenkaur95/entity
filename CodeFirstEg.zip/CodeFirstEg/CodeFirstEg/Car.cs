﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace CodeFirstEg
{
    public class Car
    {

        [Key]

        public int CarId { get; set; }

        public string Company { get; set; }

        public int YearOfMake { get; set; }

        public string Model { get; set; }
    }
}
