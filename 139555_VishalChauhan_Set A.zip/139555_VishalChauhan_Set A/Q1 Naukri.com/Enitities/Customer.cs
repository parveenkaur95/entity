﻿//**********************************************************************************************************//
// File Name : - Entity Layer
// Developer : - Vishal Chauhan
// Date      : - 05/12/2017
//**********************************************************************************************************//
using System;

namespace Enitities
{
    [Serializable]
    public class Customer
    {
        #region Fields
        private string _name;
        private string _qualification;
        private decimal _number;
        private string _address;
        private string _city;
        private string _designation;
        private DateTime _dob;
        private string _maritalStatus;
        #endregion

        #region Property
        public string NAME { get { return _name;} set {_name = value; } }
        public string QUALIFICATION { get {return _qualification; } set {_qualification = value;} }
        public decimal PHN_NUM { get {return _number; } set { _number = value; } }
        public string ADDRESS { get {return _address; } set {_address = value; } }
        public string  CITY { get {return _city; } set {_city = value; } }
        public string DESIGNATION { get { return _designation; } set { _designation = value; } }
        public DateTime DOB { get {return _dob; } set {_dob = value; } }
        public string MARITAL_STATUS { get {return _maritalStatus;} set {_maritalStatus = value; } }
        #endregion
    }
}
