﻿//**********************************************************************************************************//
// File Name : - Business Access Layer
// Developer : - Vishal Chauhan
// Date      : - 05/12/2017
//**********************************************************************************************************//

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Enitities;
using DataAccessLayer;
using UtilityLayer;
using System.Text.RegularExpressions;

namespace BusinessAccessLayer
{
    public class CustomerBL
    {
        //Add Validation
        public bool Validate(Customer cobj)
        {
            bool isValid = true;
            StringBuilder sb = new StringBuilder();
            if (cobj.NAME == string.Empty)
            {
                sb.Append("Name cannot be empty.\n");
                isValid = false;
            }
            if (!Regex.IsMatch(cobj.QUALIFICATION.ToString().Trim().ToLower(), @"[be|me|mca]{1,}"))
            {
                sb.Append("Qualifciation should be BE/ME/MCA.\n");
                isValid = false;
            }
            if (!Regex.IsMatch(cobj.PHN_NUM.ToString(), @"[0-9]{10}"))
            {
                sb.Append("Phone number should be of 10 digits and must contain Digits\n");
                isValid = false;
            }
            if (!Regex.IsMatch(cobj.CITY.Trim().ToLower(), @"[mumbai|pune|chennai|bangalore]{1,}"))
            {
                sb.Append("Invalid City Name.");
                isValid = false;
            }
            if (!Regex.IsMatch(cobj.MARITAL_STATUS.ToString().Trim().ToLower(), @"[m|u]"))
            {
                sb.Append("Marital Status Should be M(Married) or U(Unmarried)\n");
                isValid = false;
            }
            if ((DateTime.Now.Year - cobj.DOB.Year) < 18)
            {
                sb.Append("Age should be 18 years and above.\n");
                isValid = false;
            }
            if (!Regex.IsMatch(cobj.ADDRESS, @"[A-Za-z0-9\S]"))
            {
                sb.Append("Address should be alphanumeric and one space is allowed\n");
                isValid = false;
            }
            if (!Regex.IsMatch(cobj.DESIGNATION.Trim().ToLower(), @"[manager|deputymanager|assistantmanager]"))
            {
                sb.Append("Designation should be Manager/DeputyManager/AssistantManager\n");
                isValid = false;
            }
            if (isValid == false)
            {
                Console.WriteLine("\n\t\tErrors is/are :");
                Console.WriteLine(sb.ToString());
                //throw new CustomerException(sb.ToString());
            }
            return isValid;
        }

      
        //Method to add new product
        public bool AddCustomer(Customer cobj)
        {
            bool result = false;
            //checking if the product object is valid
            if (Validate(cobj))
            {
                //Creating DAL class object
                CustomerOperations co = new CustomerOperations();

                //Invoking its AddProduct method
                return co.AddCustomer(cobj);
            }
            return result;
        }

        
        //Method to display customer
        public List<Customer> DisplayCustomer()
        {
            CustomerOperations co = new CustomerOperations();
            return co.DisplayCustomer();
        }

        //Method to search customer
        public List<Customer> SearchCustomer(string customerDesignation)
        {
            CustomerOperations co = new CustomerOperations();
            return co.SearchCustomer(customerDesignation);
        }

    }
}
