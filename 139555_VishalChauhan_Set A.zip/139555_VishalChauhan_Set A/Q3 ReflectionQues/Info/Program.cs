﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PersonInfo;
using System.Reflection;

namespace Info
{
    class Program
    {
        static void Main(string[] args)
        {
            CPerson obj = new CPerson();
            Console.WriteLine("----------------------Method Info--------------------------------\n");
            MethodInfo[] methods = obj.GetType().GetMethods(BindingFlags.Public | BindingFlags.Instance);
            foreach (MethodInfo method in methods)
            {
                Console.WriteLine(method);
            }
            Console.WriteLine("\n\n----------------------Property Info--------------------------------\n");
            PropertyInfo[] properties = obj.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo property in properties)
            {
                Console.WriteLine(property);
              }

            Console.WriteLine("----------------------Field Info--------------------------------\n");
            FieldInfo[] fields = obj.GetType().GetFields(BindingFlags.Public | BindingFlags.Instance);
            foreach (FieldInfo field in fields)
            {
                Console.WriteLine(field);
            }
            Console.WriteLine("------------------------------------------------------------------------");
        }
    }
}
