﻿using System;
using System.IO;   
namespace FileInf
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {   
                //Accepting File Name with Path
                Console.WriteLine("Enter the File name with full Path : ");
                string filename = Console.ReadLine();
                
                //Making FileInfo object 
                FileInfo fileObj = new FileInfo(@filename);
                if (fileObj.Exists)
                {
                    //Print file name
                    Console.WriteLine("File Name = {0}", fileObj.Name);
                    //Print length of data in the file
                    Console.WriteLine("File length in Bytes = {0}", fileObj.Length);
                    //Print extension
                    Console.WriteLine("File Extension = {0}", fileObj.Extension);
                    //Print Full File Name
                    Console.WriteLine("File Full path = {0}", fileObj.FullName);
                    //Print Directory Name
                    Console.WriteLine("File Directory = {0}", fileObj.DirectoryName);
                    //Print Directory
                    Console.WriteLine("File Parent Directory = {0}", fileObj.Directory);
                    //Print File Creation Time
                    Console.WriteLine("File Creation Date and Time = {0}", fileObj.CreationTime.ToString("dd-MM-yyyy hh:mm:ss tt"));
                    //Print Last Write Time
                    Console.WriteLine("File Modified Date and Time = {0}", fileObj.LastWriteTime.ToString("dd-MM-yyyy hh:mm:ss tt"));
                    //Print Last Access Time
                    Console.WriteLine("File Last Access Date and Time = {0}", fileObj.LastAccessTime.ToString("dd-MM-yyyy hh:mm:ss tt"));
                    //Print Attributes
                    Console.WriteLine("File Attributes = {0}", fileObj.Attributes.ToString());
                }
                else
                {
                    Console.WriteLine("File does not Exists");
                }
            }
            catch (IOException ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadKey();
        }
    }
}
