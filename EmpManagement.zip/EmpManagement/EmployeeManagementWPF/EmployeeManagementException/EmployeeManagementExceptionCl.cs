﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagementException
{
    public class EmployeeManagementExceptionCl:ApplicationException
    {
        public EmployeeManagementExceptionCl():base()
        {

        }
        public EmployeeManagementExceptionCl(string message):base(message)
        {

        }
        public EmployeeManagementExceptionCl(string message,Exception innerexception):base(message,innerexception)
        {

        }
    }
}
