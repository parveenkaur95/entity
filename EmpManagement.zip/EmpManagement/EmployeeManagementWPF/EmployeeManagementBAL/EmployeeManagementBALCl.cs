﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeManagementEntity;
using EmployeeManagementException;
using EmployeeManagementDAL;

namespace EmployeeManagementBAL
{
    public class EmployeeManagementBALCl
    {

        public static bool ValidateEmployee(EmployeeManagementEntityCl employee)
        {
            StringBuilder sb = new StringBuilder();
            bool validEmployee = true;
      
            if (employee.EmployeeName == string.Empty)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Employee Name Required");

            }
            if (employee.DepartmentName == string.Empty)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Department Name Required");
            }
            if (employee.City == string.Empty)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "City Required");
            }
            if (employee.DateofJoin == null)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Date of joining required");
            }
            
            if (validEmployee == false)
                throw new EmployeeManagementExceptionCl(sb.ToString());
            return validEmployee;
        }


        public static bool AddEmployeeBL(EmployeeManagementEntityCl newEmp)
        {
            bool EmployeeAdded = false;
            try
            {
                if (ValidateEmployee(newEmp))
                {
                    EmployeeManagementDALCl empDAL = new EmployeeManagementDALCl();
                    EmployeeAdded = empDAL.AddEmployeeDAL(newEmp);
                }
            }
            catch (EmployeeManagementExceptionCl)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return EmployeeAdded;
        }

        public static List<EmployeeManagementEntityCl> GetAllEmployeeBL()
        {
            List<EmployeeManagementEntityCl> employeeList = null;
            try
            {
                EmployeeManagementDALCl employeeDAL = new EmployeeManagementDALCl();
                employeeList = employeeDAL.GetAllEmployeeDAL();
            }
            catch (EmployeeManagementExceptionCl ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return employeeList;
        }

        public static EmployeeManagementEntityCl SearchEmployeeBL(int searchEmployeeID)
        {
            EmployeeManagementEntityCl searchEmployee = null;
            try
            {
                EmployeeManagementDALCl employeeDAL = new EmployeeManagementDALCl();
                searchEmployee = employeeDAL.SearchEmployeeDAL(searchEmployeeID);
            }
            catch (EmployeeManagementExceptionCl ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchEmployee;

        }

        public static bool UpdateEmployeeBL(EmployeeManagementEntityCl updateEmployee)
        {
            bool employeeUpdated = false;
            try
            {
                if (ValidateEmployee(updateEmployee))
                {
                    EmployeeManagementDALCl employeeDAL = new EmployeeManagementDALCl();
                    employeeUpdated = employeeDAL.UpdateEmployeeDAL(updateEmployee);
                }
            }
            catch (EmployeeManagementExceptionCl)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return employeeUpdated;
        }

        public static bool DeleteEmployeeBL(int deleteEmployeeID)
        {
            bool employeeDeleted = false;
            try
            {
                if (deleteEmployeeID > 0)
                {
                    EmployeeManagementDALCl employeeDAL = new EmployeeManagementDALCl();
                    employeeDeleted = employeeDAL.DeleteEmployeeDAL(deleteEmployeeID);
                }
                else
                {
                    throw new EmployeeManagementExceptionCl("Invalid Employee ID");
                }
            }
            catch (EmployeeManagementExceptionCl)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return employeeDeleted;
        }

    }
}
