﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using EmployeeManagementEntity;
using EmployeeManagementException;
using EmployeeManagementBAL;

namespace EmployeeManagementPL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btn_ShowAll_Click(object sender, RoutedEventArgs e)
        {
            List<EmployeeManagementEntityCl> employeeList = EmployeeManagementBALCl.GetAllEmployeeBL();
            dataGrid.ItemsSource = employeeList;
        }

        private void btn_Add_Click(object sender, RoutedEventArgs e)
        {
            EmployeeManagementEntityCl tempemp = new EmployeeManagementEntityCl();
            //tempemp.EmployeeID= Convert.ToInt32(txt_GuestID.Text);
            tempemp.EmployeeName = txt_EmployeeName.Text;
            tempemp.City = txt_EmployeeCity.Text;
            tempemp.DepartmentName = txt_EmployeeCity.Text;
            tempemp.DateofJoin = Convert.ToDateTime(date_Doj.Text);
            try
            {
                bool empAdded = EmployeeManagementBALCl.AddEmployeeBL(tempemp);
                if (empAdded == true)
                {
                    
                    MessageBox.Show("Added");
                }
                else
                {
                    MessageBox.Show("Failed");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btn_Find_Click(object sender, RoutedEventArgs e)
        {
            int employeeid = Convert.ToInt32( txt_EmployeeID.Text);
            EmployeeManagementEntityCl searchEmployee = EmployeeManagementBALCl.SearchEmployeeBL(employeeid);
            txt_EmployeeName.Text = searchEmployee.EmployeeName;
            txt_EmployeeCity.Text = searchEmployee.City;
            txt_DepartmentName.Text = searchEmployee.DepartmentName;
            date_Doj.Text = searchEmployee.DateofJoin.ToString();
        }

        private void btn_Update_Click(object sender, RoutedEventArgs e)
        {
            bool employeeUpdated = false;
            int id = Convert.ToInt32(txt_EmployeeID.Text);
            string name = txt_EmployeeName.Text;
            string city = txt_EmployeeCity.Text;
            string dept = txt_DepartmentName.Text;
            DateTime date = Convert.ToDateTime(date_Doj.Text);
            EmployeeManagementEntityCl tempemp = new EmployeeManagementEntityCl();
            tempemp.EmployeeID = id;
            tempemp.EmployeeName = name;
            tempemp.City = city;
            tempemp.DepartmentName = dept;
            tempemp.DateofJoin = date;
            try
            {
                employeeUpdated = EmployeeManagementBALCl.UpdateEmployeeBL(tempemp);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            if (employeeUpdated == true)
            {
                MessageBox.Show("Updated!!");
            }
            else
            {
                MessageBox.Show("Not Updated!!");
            }
        }

        private void btn_Delete_Click(object sender, RoutedEventArgs e)
        {
            int id = Convert.ToInt32(txt_EmployeeID.Text);
            bool empdeleted = EmployeeManagementBALCl.DeleteEmployeeBL(id);
            if (empdeleted == true)
            {
                MessageBox.Show("Deleted");
            }
            else
            {
                MessageBox.Show("Could not delete");
            }
        }

        private void dataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            EmployeeManagementEntityCl tempemp = (EmployeeManagementEntityCl)dataGrid.CurrentCell.Item;
            txt_EmployeeID.Text = tempemp.EmployeeID.ToString();
            txt_EmployeeName.Text = tempemp.EmployeeName;
            txt_EmployeeCity.Text = tempemp.City;
            txt_DepartmentName.Text = tempemp.DepartmentName;
            date_Doj.Text = tempemp.DateofJoin.ToString();
            
        }
    }
}
