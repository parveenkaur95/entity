﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace EmployeeManagementDAL
{
    public class EmployeeManagementConfiguration
    {
        private static string providerName;
        public static string PROVIDERNAME { get {return providerName; } set {providerName=value; } }

        private static string connectionString;

        public static string CONNECTIONSTRING
        {
            get { return EmployeeManagementConfiguration.connectionString; }
            set { EmployeeManagementConfiguration.connectionString = value; }
        }

        static EmployeeManagementConfiguration()
        {
            providerName = ConfigurationManager.ConnectionStrings["Training"].ProviderName;
            connectionString = ConfigurationManager.ConnectionStrings["Training"].ConnectionString;
        }

    }
}
