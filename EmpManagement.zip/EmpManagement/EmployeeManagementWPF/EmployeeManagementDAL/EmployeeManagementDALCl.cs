﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeManagementEntity;
using EmployeeManagementException;
using System.Data;
using System.Data.Common;

namespace EmployeeManagementDAL
{
    public class EmployeeManagementDALCl
    {
        public bool AddEmployeeDAL(EmployeeManagementEntityCl newEmp)
        {
            bool employeeAdded = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "uspAddEmployee";

                DbParameter param = command.CreateParameter();
                //param.ParameterName = "@ipv_iEmployeeID";
                //param.DbType = DbType.Int32;
                //param.Value = newEmp.EmployeeID;
                //command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@ipv_vcEmployeeName";
                param.DbType = DbType.String;
                param.Value = newEmp.EmployeeName;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@ipv_vcCity";
                param.DbType = DbType.String;
                param.Value = newEmp.City;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@ipv_vcDepartmentName";
                param.DbType = DbType.String;
                param.Value = newEmp.DepartmentName;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@ipv_vcDateOfJoin";
                param.DbType = DbType.DateTime;
                param.Value = newEmp.DateofJoin;
                command.Parameters.Add(param);

                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    employeeAdded = true;
            }
            catch (DbException ex)
            {
                string errormessage;

                switch (ex.ErrorCode)
                {
                    case -2146232060:
                        errormessage = "Database Does NotExists Or AccessDenied";
                        break;
                    default:
                        errormessage = ex.Message;
                        break;
                }
                throw new EmployeeManagementExceptionCl(errormessage);
            }
            return employeeAdded;

        }

        public List<EmployeeManagementEntityCl> GetAllEmployeeDAL()
        {
            List<EmployeeManagementEntityCl> employeeList = null;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "uspGetAllEmployee";



                DataTable dataTable = DataConnection.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0)
                {
                    employeeList = new List<EmployeeManagementEntityCl>();
                    for (int rowCounter = 0; rowCounter < dataTable.Rows.Count; rowCounter++)
                    {
                        EmployeeManagementEntityCl emp = new EmployeeManagementEntityCl();
                        emp.EmployeeID = (int)dataTable.Rows[rowCounter][0];
                        emp.EmployeeName = (string)dataTable.Rows[rowCounter][1];
                        emp.City = (string)dataTable.Rows[rowCounter][2];
                        emp.DepartmentName = (string)dataTable.Rows[rowCounter][3];
                        emp.DateofJoin = (DateTime)dataTable.Rows[rowCounter][4];
                        employeeList.Add(emp);
                    }
                }
            }
            catch (DbException ex)
            {
                throw new EmployeeManagementExceptionCl(ex.Message);
            }
            return employeeList;
        }

        public EmployeeManagementEntityCl SearchEmployeeDAL(int searchEmployeeID)
        {
            EmployeeManagementEntityCl searchEmployee = null;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "uspSearchEmployee";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@ipv_iEmployeeID";
                param.DbType = DbType.Int32;
                param.Value = searchEmployeeID;
                command.Parameters.Add(param);

                DataTable dataTable = DataConnection.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0)
                {
                    searchEmployee = new EmployeeManagementEntityCl();
                    searchEmployee.EmployeeID= (int)dataTable.Rows[0][0];
                    searchEmployee.EmployeeName = (string)dataTable.Rows[0][1];
                    searchEmployee.City = (string)dataTable.Rows[0][2];
                    searchEmployee.DepartmentName = (string)dataTable.Rows[0][3];
                    searchEmployee.DateofJoin = (DateTime)dataTable.Rows[0][4];
                }
            }
            catch (DbException ex)
            {
                throw new EmployeeManagementExceptionCl(ex.Message);
            }
            return searchEmployee;
        }

        public bool UpdateEmployeeDAL(EmployeeManagementEntityCl updateEmployee)
        {
            bool employeeUpdated = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "uspUpdateEmployee";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@ipv_iEmployeeID";
                param.DbType = DbType.Int32;
                param.Value = updateEmployee.EmployeeID;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@ipv_vcEmployeeName";
                param.DbType = DbType.String;
                param.Value = updateEmployee.EmployeeName;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@ipv_vcCity";
                param.DbType = DbType.String;
                param.Value = updateEmployee.City;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@ipv_vcDepartmentName";
                param.DbType = DbType.String;
                param.Value = updateEmployee.DepartmentName;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@ipv_vcDateOfJoin";
                param.DbType = DbType.DateTime;
                param.Value = updateEmployee.DateofJoin;
                command.Parameters.Add(param);

                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    employeeUpdated = true;
            }
            catch (DbException ex)
            {
                throw new EmployeeManagementExceptionCl(ex.Message);
            }
            return employeeUpdated;

        }

        public bool DeleteEmployeeDAL(int deleteEmployeeID)
        {
            bool employeeDeleted = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "uspDeleteEmployee";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@ipv_iEmployeeID";
                param.DbType = DbType.Int32;
                param.Value = deleteEmployeeID;
                command.Parameters.Add(param);

                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    employeeDeleted = true;
            }
            catch (DbException ex)
            {
                throw new EmployeeManagementExceptionCl(ex.Message);
            }
            return employeeDeleted;

        }

    }
}
