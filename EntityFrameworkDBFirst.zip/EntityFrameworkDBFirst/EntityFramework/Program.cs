﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityFramework
{
    class Program
    {
        static void Main(string[] args)
        {
            //Query
            trainingEntities context = new trainingEntities();

            var result = from emp in context.Employees
                         where emp.EmployeeId == 4
                         select emp;

            foreach (Employee e in result)
            {
                Console.WriteLine("{0}{1}", e.EmployeeId, e.Name);

            }


            //Add emp
            Employee newEmp = new Employee();
            newEmp.EmployeeId = 4;
            newEmp.Name = "Parveen";

            context.Employees.Add(newEmp);

            //Delete

            Employee tobedeleted = (from emp in context.Employees
                                    where emp.EmployeeId == 10000
                                    select emp).FirstOrDefault();
            context.Employees.Remove(tobedeleted);


            //Update

            Employee tobeUpdated = (from emp in context.Employees
                                    where emp.EmployeeId == 10000
                                    select emp).FirstOrDefault();

            tobeUpdated.EmployeeId = 1234;


            context.SaveChanges();

            Console.ReadLine();
        }
    }
}
